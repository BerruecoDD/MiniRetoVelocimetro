import UIKit

enum Velocidades : Int{
    case apagado = 0, velocidadBaja = 20, velocidadMedia = 50, velocidadAlta = 120
    
    init(velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    
    init(){
        self.velocidad = Velocidades.apagado
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena : String) {//Funcion CDV
        
        let velocidadActual = velocidad.rawValue
        switch velocidad {
        case .apagado :
            self.velocidad = Velocidades.velocidadBaja
            return (velocidadActual,"El auto se encuentra apagado")
        case .velocidadBaja:
            self.velocidad = Velocidades.velocidadMedia
            return (velocidadActual,"El auto lleva una velocidad baja")
        case .velocidadMedia:
            self.velocidad = Velocidades.velocidadAlta
            return (velocidadActual,"El auto lleva una velocidad media")
        case .velocidadAlta:
            self.velocidad = Velocidades.velocidadMedia
            return (velocidadActual, "El auto lleva una velocidad alta")
        }
    }
}

var auto = Auto()
for _ in 1...10{
    let (velocidadActual, mensaje) = auto.cambioDeVelocidad()
    print("\(velocidadActual), \(mensaje)")
}
